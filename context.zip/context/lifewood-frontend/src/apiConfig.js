// src/apiConfig.js

// This file's ONLY purpose is to export your backend's live URL as a string.
const API_BASE_URL = 'https://lifewoodweb.onrender.com';
// const API_BASE_URL = 'http://localhost:5173';

export default API_BASE_URL;